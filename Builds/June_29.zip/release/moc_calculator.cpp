/****************************************************************************
** Meta object code from reading C++ file 'calculator.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.13.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../Calculator/calculator.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'calculator.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.13.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Calculator_t {
    QByteArrayData data[34];
    char stringdata0[461];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Calculator_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Calculator_t qt_meta_stringdata_Calculator = {
    {
QT_MOC_LITERAL(0, 0, 10), // "Calculator"
QT_MOC_LITERAL(1, 11, 10), // "NumPressed"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 17), // "MathButtonPressed"
QT_MOC_LITERAL(4, 41, 11), // "EqualButton"
QT_MOC_LITERAL(5, 53, 16), // "ChangeNumberSign"
QT_MOC_LITERAL(6, 70, 18), // "ClearButtonPressed"
QT_MOC_LITERAL(7, 89, 9), // "MemoryAdd"
QT_MOC_LITERAL(8, 99, 11), // "MemoryClear"
QT_MOC_LITERAL(9, 111, 9), // "MemoryGet"
QT_MOC_LITERAL(10, 121, 9), // "PiPressed"
QT_MOC_LITERAL(11, 131, 19), // "EulersNumberPressed"
QT_MOC_LITERAL(12, 151, 19), // "RandomNumberPressed"
QT_MOC_LITERAL(13, 171, 19), // "DecimalPointPressed"
QT_MOC_LITERAL(14, 191, 16), // "ClearAllTriggers"
QT_MOC_LITERAL(15, 208, 21), // "ClearOperatorTriggers"
QT_MOC_LITERAL(16, 230, 13), // "GetMathButton"
QT_MOC_LITERAL(17, 244, 28), // "PressedOnEqualButtonDirectly"
QT_MOC_LITERAL(18, 273, 13), // "PercentButton"
QT_MOC_LITERAL(19, 287, 9), // "Factorial"
QT_MOC_LITERAL(20, 297, 14), // "SquaredOrCubed"
QT_MOC_LITERAL(21, 312, 6), // "Powers"
QT_MOC_LITERAL(22, 319, 14), // "EToThePowerOfX"
QT_MOC_LITERAL(23, 334, 11), // "ToTheXPower"
QT_MOC_LITERAL(24, 346, 16), // "SquareOrCubeRoot"
QT_MOC_LITERAL(25, 363, 14), // "releaseButtons"
QT_MOC_LITERAL(26, 378, 8), // "OneOverX"
QT_MOC_LITERAL(27, 387, 8), // "RadOrDeg"
QT_MOC_LITERAL(28, 396, 22), // "TrigAndHyperbFunctions"
QT_MOC_LITERAL(29, 419, 10), // "NaturalLog"
QT_MOC_LITERAL(30, 430, 3), // "Log"
QT_MOC_LITERAL(31, 434, 8), // "LogBaseY"
QT_MOC_LITERAL(32, 443, 2), // "EE"
QT_MOC_LITERAL(33, 446, 14) // "displayIsEmpty"

    },
    "Calculator\0NumPressed\0\0MathButtonPressed\0"
    "EqualButton\0ChangeNumberSign\0"
    "ClearButtonPressed\0MemoryAdd\0MemoryClear\0"
    "MemoryGet\0PiPressed\0EulersNumberPressed\0"
    "RandomNumberPressed\0DecimalPointPressed\0"
    "ClearAllTriggers\0ClearOperatorTriggers\0"
    "GetMathButton\0PressedOnEqualButtonDirectly\0"
    "PercentButton\0Factorial\0SquaredOrCubed\0"
    "Powers\0EToThePowerOfX\0ToTheXPower\0"
    "SquareOrCubeRoot\0releaseButtons\0"
    "OneOverX\0RadOrDeg\0TrigAndHyperbFunctions\0"
    "NaturalLog\0Log\0LogBaseY\0EE\0displayIsEmpty"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Calculator[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      32,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  174,    2, 0x08 /* Private */,
       3,    0,  175,    2, 0x08 /* Private */,
       4,    0,  176,    2, 0x08 /* Private */,
       5,    0,  177,    2, 0x08 /* Private */,
       6,    0,  178,    2, 0x08 /* Private */,
       7,    0,  179,    2, 0x08 /* Private */,
       8,    0,  180,    2, 0x08 /* Private */,
       9,    0,  181,    2, 0x08 /* Private */,
      10,    0,  182,    2, 0x08 /* Private */,
      11,    0,  183,    2, 0x08 /* Private */,
      12,    0,  184,    2, 0x08 /* Private */,
      13,    0,  185,    2, 0x08 /* Private */,
      14,    0,  186,    2, 0x08 /* Private */,
      15,    0,  187,    2, 0x08 /* Private */,
      16,    0,  188,    2, 0x08 /* Private */,
      17,    0,  189,    2, 0x08 /* Private */,
      18,    0,  190,    2, 0x08 /* Private */,
      19,    0,  191,    2, 0x08 /* Private */,
      20,    0,  192,    2, 0x08 /* Private */,
      21,    0,  193,    2, 0x08 /* Private */,
      22,    0,  194,    2, 0x08 /* Private */,
      23,    0,  195,    2, 0x08 /* Private */,
      24,    0,  196,    2, 0x08 /* Private */,
      25,    0,  197,    2, 0x08 /* Private */,
      26,    0,  198,    2, 0x08 /* Private */,
      27,    0,  199,    2, 0x08 /* Private */,
      28,    0,  200,    2, 0x08 /* Private */,
      29,    0,  201,    2, 0x08 /* Private */,
      30,    0,  202,    2, 0x08 /* Private */,
      31,    0,  203,    2, 0x08 /* Private */,
      32,    0,  204,    2, 0x08 /* Private */,
      33,    0,  205,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Bool,

       0        // eod
};

void Calculator::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Calculator *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->NumPressed(); break;
        case 1: _t->MathButtonPressed(); break;
        case 2: _t->EqualButton(); break;
        case 3: _t->ChangeNumberSign(); break;
        case 4: _t->ClearButtonPressed(); break;
        case 5: _t->MemoryAdd(); break;
        case 6: _t->MemoryClear(); break;
        case 7: _t->MemoryGet(); break;
        case 8: _t->PiPressed(); break;
        case 9: _t->EulersNumberPressed(); break;
        case 10: _t->RandomNumberPressed(); break;
        case 11: _t->DecimalPointPressed(); break;
        case 12: _t->ClearAllTriggers(); break;
        case 13: _t->ClearOperatorTriggers(); break;
        case 14: _t->GetMathButton(); break;
        case 15: _t->PressedOnEqualButtonDirectly(); break;
        case 16: _t->PercentButton(); break;
        case 17: _t->Factorial(); break;
        case 18: _t->SquaredOrCubed(); break;
        case 19: _t->Powers(); break;
        case 20: _t->EToThePowerOfX(); break;
        case 21: _t->ToTheXPower(); break;
        case 22: _t->SquareOrCubeRoot(); break;
        case 23: _t->releaseButtons(); break;
        case 24: _t->OneOverX(); break;
        case 25: _t->RadOrDeg(); break;
        case 26: _t->TrigAndHyperbFunctions(); break;
        case 27: _t->NaturalLog(); break;
        case 28: _t->Log(); break;
        case 29: _t->LogBaseY(); break;
        case 30: _t->EE(); break;
        case 31: { bool _r = _t->displayIsEmpty();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Calculator::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_Calculator.data,
    qt_meta_data_Calculator,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Calculator::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Calculator::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Calculator.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Calculator::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 32)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 32;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 32)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 32;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
